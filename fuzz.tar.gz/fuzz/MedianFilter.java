//MedianFilter.java

import java.lang.*;
import java.io.*;
import javax.swing.*;

public class MedianFilter extends Filter
{
	private String InFilePath,OutFilePath;
	public boolean PrintStatus=false;
	private double meanSquareError,snr,psnrMaxValue,psnrPeakValue;
	private double[] MSE;
	
	//constructor
	public MedianFilter()
	{
		InFilePath="";
		OutFilePath="";
	}

	//get functions
	public String getInFilePath()
	{
		return(InFilePath);
	}
	
	public String getOutFilePath()
	{
		return(OutFilePath);
	}
	
	//set functions
	public void setInFilePath(String tFilePath)
	{
		InFilePath=tFilePath;
	}
	
	public void setOutFilePath(String tFilePath)
	{
		OutFilePath=tFilePath;
	}

	public void process(int tIterations,boolean p)
	{
		PGM imgin=new PGM();
		PGM imgout=new PGM();
		int nrows, ncols;
	  	int img1[][], img2[][];
      	double  peak=0, signal=0, noise=0, mse=0;
      	MSE = new double[tIterations];
	
		if(PrintStatus==true&&p==true)
		{
				System.out.println("\n MEDIAN FILTER \n");
				System.out.println(" Applying smoothing process");
		}
	
		//read input image
		imgin.setFilePath(InFilePath);

		if(!imgin.readImage())
			return;		// if the input image cannot be read,
						// readImage() in PGM class will display the error
		
		nrows=imgin.getRows();
	    ncols=imgin.getCols();
      	img1 = new int[nrows][ncols];
      	img2 = new int[nrows][ncols];
      	
		//set output-image header
		imgout.setFilePath(OutFilePath);
		imgout.setType("P5");
		imgout.setComment("#median-filtered image");
		imgout.setDimension(imgin.getCols(),imgin.getRows());
		imgout.setMaxGray(imgin.getMaxGray());
		
		for(int r=0;r<nrows;r++)
		{
    		for(int c=0;c<ncols;c++)
    		{
       			img1[r][c]=imgin.getPixel(r,c);
    		}
    	}
	
		//smoothing algorithm (median)
		for(int t=1;t<=tIterations;t++)
		{
			if(PrintStatus==true&&p==true)
			{
				System.out.print("\n Iteration : "+t+"...");
			}
			for(int r=0;r<imgout.getRows();r++)
			{
				for(int c=0;c<imgout.getCols();c++)
				{
					int inval=imgin.getPixel(r,c); //get current pixel
	
					//get neighborhood pixel intensity values
					int neighbor[]=new int[9];
					neighbor[0]=imgin.getNeighbor(r,c,Globals.NW);
					neighbor[1]=imgin.getNeighbor(r,c,Globals.W );
					neighbor[2]=imgin.getNeighbor(r,c,Globals.SW);
					neighbor[3]=imgin.getNeighbor(r,c,Globals.S );
					neighbor[4]=imgin.getNeighbor(r,c,Globals.SE);
					neighbor[5]=imgin.getNeighbor(r,c,Globals.E);
					neighbor[6]=imgin.getNeighbor(r,c,Globals.NE);
					neighbor[7]=imgin.getNeighbor(r,c,Globals.N );
					neighbor[8]=inval;
	
					//calculate new intensity value
					for(int i=0;i<=7;i++)
					{
						for(int j=i+1;j<=8;j++)
						{
							if(neighbor[i]>neighbor[j])
							{
								int temp=neighbor[i];
								neighbor[i]=neighbor[j];
								neighbor[j]=temp;
							}
						}
					}
					int outval=neighbor[4];

					imgout.setPixel(r,c,outval);
					img2[r][c]=imgout.getPixel(r,c);
					
					signal += img1[r][c] * img1[r][c];
        			noise += (img1[r][c] - img2[r][c]) * (img1[r][c] - img2[r][c]);
        			if (peak < img1[r][c])
          					peak = img1[r][c];
				}
			}	
			//set outputimage as input to next iteration (if not last iteration)
			if(t!=tIterations)
			{
				for(int r=0;r<imgin.getRows();r++)
				{
					for(int c=0;c<imgin.getCols();c++)
					{
						imgin.setPixel(r,c,imgout.getPixel(r,c));
					}
				}
			}
			MSE[t-1] = noise/(nrows*ncols);
			signal=0;
			peak=0;
			noise=0;
		}
		if(PrintStatus==true&&p==true)
		{
			System.out.println("\n Median Filter Applied");
		}
		//write output image
		if(p==true)
			imgout.writeImage();
		else
			drawGraph();
		if(p==true)
		{
		//calculating PSNR	
    	for(int r=0;r<nrows;r++){
    		for(int c=0;c<ncols;c++){
       			img2[r][c]=imgout.getPixel(r,c);
    		}
    	}
    	signal = noise = peak = 0;
    	for (int i=0; i<nrows; i++) {
      		for (int j=0; j<ncols; j++) {
        		signal += img1[i][j] * img1[i][j];
        		noise += (img1[i][j] - img2[i][j]) * (img1[i][j] - img2[i][j]);
        		if (peak < img1[i][j])
          			peak = img1[i][j];
      		}
    	}
    	mse = noise/(nrows*ncols); // Mean square error
		
		System.out.println(" Noise Parameters : \n");
    	System.out.println(" Mean Square Error (MSE)     : " + mse);
    	System.out.println(" Signal to noise ratio (SNR) : " + 10*log10(signal/noise));
    	System.out.println(" PSNR (max = 255)            : " + (10*log10(255*255/mse)));
    	System.out.println(" PSNR (max = "+ peak +")          : " + 10*log10((peak*peak)/mse));	
    	System.out.println();
    	
    	meanSquareError=mse;
    	snr=10*log10(signal/noise);
    	psnrMaxValue=(10*log10(255*255/mse));
    	psnrPeakValue=10*log10((peak*peak)/mse);
    	}	
	}
  public static double log10(double x) {
    return Math.log(x)/Math.log(10);
  }
  //get functions to get Noise parameters		
  public double getMsr(){
  	return meanSquareError;
  }
  public double getSnr(){
  	return snr;
  }
  public double getPsnrMaxValue(){
  	return psnrMaxValue;
  }
  public double getPsnrPeakValue(){
  	return psnrPeakValue;
  }	
  public void drawGraph(){
  	    JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.add(new GraphingData(MSE,'d'));
        f.setSize(600,600);
        f.setLocation(300,100);
        f.setVisible(true);
        f.setResizable(false);
        f.setTitle("MSE vs Iteration - Median Filter");
  }	
}