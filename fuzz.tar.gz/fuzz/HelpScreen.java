import java.io.*;
public class HelpScreen extends javax.swing.JFrame {

    /** Creates new form HelpScreen */
    public HelpScreen(char x) {
        initComponents(x);
    }

    @SuppressWarnings("unchecked")

    private void initComponents(char x) {

		StringBuffer sb=new StringBuffer("");
		sb.setLength(5000);
		
        jLabel1 = new javax.swing.JLabel();
        textArea1 = new java.awt.TextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Help");
        setBounds(new java.awt.Rectangle(320, 200, 0, 0));
        setResizable(false);
        
        textArea1.setEditable(false);

        jLabel1.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); 
        switch(x){
        	case 'n':	
        			jLabel1.setText("Noise in Images");
        			try{
							InputStream f=new FileInputStream("helpFiles//noise.txt");
							int size=f.available();
							for(int i=0;i<size;i++){
								sb.setCharAt(i,(char)f.read());
							}
							f.close();
				    }
					catch(IOException e){	
					}
        			break;
        	case 'm':	
        			jLabel1.setText("About Mean Filter");
        			try{
							InputStream f=new FileInputStream("helpFiles//meanFilter.txt");
							int size=f.available();
							for(int i=0;i<size;i++){
								sb.setCharAt(i,(char)f.read());
							}
							f.close();
					}
					catch(IOException e){	
					}
        			break;
        	case 'd':	
        			jLabel1.setText("About Median Filter");
        			try{
							InputStream f=new FileInputStream("helpFiles//medianFilter.txt");
							int size=f.available();
							for(int i=0;i<size;i++){
								sb.setCharAt(i,(char)f.read());
							}
							f.close();
					}
					catch(IOException e){	
					}
        			break;
        	case 'e':	
        			jLabel1.setText("About Edge Filter");
        			try{
							InputStream f=new FileInputStream("helpFiles//edgeFilter.txt");
							int size=f.available();
							for(int i=0;i<size;i++){
								sb.setCharAt(i,(char)f.read());
							}
							f.close();
					}
					catch(IOException e){	
					}
        			break;
        	case 'z':	
        			jLabel1.setText("About Fuzzy Filter");
        			try{
							InputStream f=new FileInputStream("helpFiles//fuzzyFilter.txt");
							int size=f.available();
							for(int i=0;i<size;i++){
								sb.setCharAt(i,(char)f.read());
							}
							f.close();
					}
					catch(IOException e){	
					}
        			break;
        	case 'p':	
        			jLabel1.setText("Noise Parameters");
         			try{
							InputStream f=new FileInputStream("helpFiles//noiseParameters.txt");
							int size=f.available();
							for(int i=0;i<size;i++){
								sb.setCharAt(i,(char)f.read());
							}
							f.close();
					}
					catch(IOException e){	
					}
					break;
        }
        String s=new String(sb);
        textArea1.setText(s);
        

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(textArea1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 430, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 430, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(textArea1, javax.swing.GroupLayout.DEFAULT_SIZE, 286, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }
    private javax.swing.JLabel jLabel1;
    private java.awt.TextArea textArea1;
    // End of variables declaration
}
