folder contals all project dada
paste folder in jdk/bin
set path
run
>java FuzzyNoiseReduction