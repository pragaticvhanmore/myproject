//Fuzzy.java

import java.lang.*;
import java.io.*;

//'small' fuzzy set
class SmallFuzzySet
{
	//membership function for 'small' fuzzy set
	//
	//      { 1-(x/K), if x<=K
	// f(x)={
	//      { 0, if x>K
	//
	public static double fofx(int x,int K)
	{
		double fxdegree;
	
		if(x>K) fxdegree=0.0;
		else    fxdegree=1.0-Math.abs((double)x/(double)K);
	
		return(fxdegree);
	}
	
	//fuzzy rule for 'small' fuzzy set
	//
	// IF       sdcurrent is small AND sdperpendicular1 is small OR }
	// IF       sdcurrent is small AND sdperpendicular2 is small OR } THEN ans is small
	// IF sdperpendicular is small AND sdperpendicular2 is small    }
	//
	public static double ApplyRule(double sdcurrent,double sdperpendicular1,double sdperpendicular2)
	{
		double ans,val1,val2,val3;
	
		val1=sdcurrent;
		val2=sdperpendicular1;
		val3=sdperpendicular2;
	
		ans=Math.min(val1,val2);
		ans=Math.max(ans,Math.min(val1,val3));
		ans=Math.max(ans,Math.min(val2,val3));
	
		return(ans);
	}
}

//'+ve' fuzzy set
class PositiveFuzzySet{

	//membership function for '+ve' fuzzy set
	//
	//      { x/L, if x>0
	// f(x)={
	//      { 0, if x<=0
	//
	public static double fofx(int x,int L)
	{
		double fxdegree;
	
		if(x<=0) fxdegree=0.0;
		else     fxdegree=Math.abs((double)x/(double)L);
	
		return(fxdegree);
	}
	
	//fuzzy rule for '+ve' fuzzy set
	//
	// IF simpderiv is +ve AND val is +ve THEN ans is +ve
	//
	public static double ApplyRule(double simpderiv,double val)
	{
		return(Math.min(simpderiv,val));
	}
}

//'-ve' fuzzy set
class NegativeFuzzySet
{
	//membership function for '-ve' fuzzy set
	//
	//      { x/L, if x<0
	// f(x)={
	//      { 0, if x>=0
	//
	public static double fofx(int x,int L)
	{
		double fxdegree;
	
		if(x>=0) fxdegree=0.0;
		else     fxdegree=Math.abs((double)x/(double)L);
	
		return(fxdegree);
	}
	
	//fuzzy rule for '-ve' fuzzy set
	//
	// IF simpderiv is -ve AND val is -ve THEN ans is -ve
	//
	public static double ApplyRule(double simpderiv,double val)
	{
		return(Math.min(simpderiv,val));
	}
}
