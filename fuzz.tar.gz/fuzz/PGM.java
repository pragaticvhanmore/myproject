//PGM.java

import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.filechooser.*;
import javax.imageio.*;

public class PGM
{
	private String FilePath;

	//pgm imageheader
	private String Type;
	private String Comment;
	private int Cols,Rows,MaxGray;

	//pgm imagedata
	private int[][] Pixels;
	
	//constructor
	public PGM()
	{
		FilePath="";
		Type="";
		Comment="";
		Cols=0;
		Rows=0;
		MaxGray=0;
		Pixels=null;
	}

	//get functions
	public String getFilePath()
	{
		return(FilePath);
	}

	public String getType()
	{
		return(Type);
	}

	public String getComment()
	{
		return(Comment);
	}

	public int getCols()
	{
		return(Cols);
	}

	public int getRows()
	{
		return(Rows);
	}

	public int getMaxGray()
	{
		return(MaxGray);
	}

	public int getPixel(int tr,int tc)
	{
		return(tr<0||tr>Rows-1||tc<0||tc>Cols-1?0:Pixels[tr][tc]);
	}

	public int getNeighbor(int tr,int tc,int direction)
	{
		int pval=0;
		if     (direction==Globals.NW) pval=getPixel(tr-1,tc-1);
		else if(direction==Globals.W ) pval=getPixel(tr  ,tc-1);
		else if(direction==Globals.SW) pval=getPixel(tr+1,tc-1);
		else if(direction==Globals.S ) pval=getPixel(tr+1,tc  );
		else if(direction==Globals.SE) pval=getPixel(tr+1,tc+1);
		else if(direction==Globals.E ) pval=getPixel(tr  ,tc+1);
		else if(direction==Globals.NE) pval=getPixel(tr-1,tc+1);
		else if(direction==Globals.N ) pval=getPixel(tr-1,tc  );
		return(pval);
	}

	//set functions
	public void setFilePath(String tFilePath)
	{
		FilePath=tFilePath;
	}

	public void setType(String tType)
	{
		Type=tType;
	}

	public void setComment(String tComment)
	{
		Comment=tComment;
	}

	public void setDimension(int tCols,int tRows)
	{
		Rows=tRows;
		Cols=tCols;
		Pixels=new int[Rows][Cols];
	}

	public void setMaxGray(int tMaxGray)
	{
		MaxGray=tMaxGray;
	}

	public void setPixel(int tr,int tc,int tval)
	{
		if(tr<0||tr>Rows-1||tc<0||tc>Cols-1) return;
		else Pixels[tr][tc]=tval;
	}

	//method to read a PGM image
	public boolean readImage()
	{
		try
		{
			FileInputStream fin=new FileInputStream(FilePath);
	
		    int c;
		    String tstr;
		    
		    //read first line of ImageHeader
		    tstr="";
		    c=fin.read();
		    tstr+=(char)c;
		    c=fin.read();
		    tstr+=(char)c;
		    Type=tstr;
		    
		    //read second line of ImageHeader
		    c=fin.read(); //read Lf (linefeed)
		    c=fin.read(); //read '#'
			tstr="";
		    boolean iscomment=false;
		    while((char)c=='#') //read comment
		    {
				iscomment=true;
			    tstr+=(char)c;
		        while(c!=10&&c!=13)
		        {
		            c=fin.read();
				    tstr+=(char)c;
		     	}
		        c=fin.read(); //read next '#'
		 	}
		    if(tstr.equals("")==false) // false=false--true
		    {
		    	Comment=tstr.substring(0,tstr.length()-1);
		    	fin.skip(-1);
		    }
		    
		    //read third line of ImageHeader
		    //read cols
		    tstr="";
			if(iscomment==true) c=fin.read();
		    tstr+=(char)c;
		    while(c!=32&&c!=10&&c!=13)
		    {
		        c=fin.read();
		        tstr+=(char)c;
		 	}
		    tstr=tstr.substring(0,tstr.length()-1);
		    Cols=Integer.parseInt(tstr);
		    
		    //read rows
			c=fin.read();
			tstr="";
		    tstr+=(char)c;
		    while(c!=32&&c!=10&&c!=13)
		    {
		        c=fin.read();
		        tstr+=(char)c;
		 	}
		    tstr=tstr.substring(0,tstr.length()-1);
		    Rows=Integer.parseInt(tstr);
		    
		    //read maxgray
			c=fin.read();
			tstr="";
		    tstr+=(char)c;
		    while(c!=32&&c!=10&&c!=13)
		    {
		        c=fin.read();
		        tstr+=(char)c;
		 	}
		    tstr=tstr.substring(0,tstr.length()-1);
		    MaxGray=Integer.parseInt(tstr);
		    
		    //read pixels from ImageData
			Pixels=new int[Rows][Cols];
		    for(int tr=0;tr<Rows;tr++)
		    {
		    	for(int tc=0;tc<Cols;tc++)
		    	{
		    		c=(int)fin.read();
		    		setPixel(tr,tc,c);
		    	}
		    }
	    
			fin.close();
		}
		catch(Exception err)
		{
			System.out.println("File Not Found");
			final String s="File Not Found";
        	java.awt.EventQueue.invokeLater(new Runnable() {
            	public void run() {
                	new ExceptionClass(s).setVisible(true);
            	}
        	});
        	return false;
		}
		return true;
	}

	public void writeImage()
	{
		try
		{
			FileOutputStream fout=new FileOutputStream(FilePath);
			
			//write image header
			//write PGM magic value 'P5'
			String tstr;
			tstr="P5"+"\n";
			fout.write(tstr.getBytes());
			
			//write comment
			Comment=Comment+"\n";
			//fout.write(comment.getBytes());

			//write cols
			tstr=Integer.toString(Cols);
			fout.write(tstr.getBytes());
			fout.write(32); //write blank space
			
			//write rows
			tstr=Integer.toString(Rows);
			fout.write(tstr.getBytes());
			fout.write(32); //write blank space
			
			//write maxgray
			tstr=Integer.toString(MaxGray);
			tstr=tstr+"\n";
			fout.write(tstr.getBytes());
			
			for(int r=0;r<Rows;r++)
			{
				for(int c=0;c<Cols;c++)
				{
					fout.write(getPixel(r,c));
				}
			}

			fout.close();
		}
		catch(Exception err)
		{
			System.out.println("Error in writing image");
			final String s="Error in writing image";
        	java.awt.EventQueue.invokeLater(new Runnable() {
            	public void run() {
                	new ExceptionClass(s).setVisible(true);
            	}
        	});
		}
	}

	public void writeImageAs(String tFilePath)
	{
		PGM imgout=new PGM();
		imgout.setFilePath(tFilePath);
		imgout.setType(getType());
		imgout.setComment(getComment());
		imgout.setDimension(getCols(),getRows());
		imgout.setMaxGray(getMaxGray());
		
		for(int r=0;r<getRows();r++)
		{
			for(int c=0;c<getCols();c++)
			{
				imgout.setPixel(r,c,getPixel(r,c));
			}
		}
		
		imgout.writeImage();
	}
	
	public static int getRGBValue(int tred,int tgreen,int tblue)
	{
		return((tred<<16)+(tgreen<<8)+tblue);
	}
	
	public BufferedImage getBufferedImage()
	{
		BufferedImage timg=new BufferedImage(Cols,Rows,BufferedImage.TYPE_INT_RGB);
		
		for(int r=0;r<getRows();r++)
		{
			for(int c=0;c<getCols();c++)
			{
				int tgray=getPixel(r,c);
				int trgb=getRGBValue(tgray,tgray,tgray);
				timg.setRGB(c,r,trgb);
			}
		}
		
		return(timg);
	}
}