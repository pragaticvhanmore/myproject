import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.filechooser.*;
import javax.imageio.*;
import java.awt.geom.*;

public class CompareImages extends javax.swing.JFrame {

	MyPictureBox pbInput;
	MyPictureBox pbMean;
	MyPictureBox pbMedian;
	MyPictureBox pbFuzzy;
	
	String InputFilePath;
	String OutputFilePath;
	
	double mseMen,snrMen,psnrMMen,psnrPMen;
    double mseMed,snrMed,psnrMMed,psnrPMed;
    double mseFuz,snrFuz,psnrMFuz,psnrPFuz;
    
    MyContentPane mcp = new MyContentPane() ;
	
    /** Creates new form NewJFrame */
    public CompareImages(String ifp) {
    	
    	pbInput = new MyPictureBox();
    	pbMean = new MyPictureBox();
    	pbMedian = new MyPictureBox();
    	pbFuzzy = new MyPictureBox();
    	
    	InputFilePath=ifp;
    	OutputFilePath="";
    	  
        initComponents();
    }

    @SuppressWarnings("unchecked")
   
    private void initComponents() {
        
        
        jInternalFrame1 = new javax.swing.JInternalFrame(); // input
        jInternalFrame3 = new javax.swing.JInternalFrame(); // mean
        jInternalFrame4 = new javax.swing.JInternalFrame(); // median
        jInternalFrame2 = new javax.swing.JInternalFrame(); // fuzzy
        
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

		mcp = new MyContentPane() ;
		Container container = getContentPane() ;
		container.add(mcp) ;
		        
        pbInput.setBounds(0,-22,290,605);
		jInternalFrame1.getContentPane().add(pbInput);
		
		pbMean.setBounds(0,-22,275,605);
		jInternalFrame2.getContentPane().add(pbMean);
		
		pbMedian.setBounds(0,-22,289,605);
		jInternalFrame3.getContentPane().add(pbMedian);
		
		pbFuzzy.setBounds(0,-22,292,605);
		jInternalFrame4.getContentPane().add(pbFuzzy);

				// Output input image
				PGM tpgm=new PGM();
				tpgm.setFilePath(InputFilePath);
				tpgm.readImage();
				pbInput.setImage(tpgm.getBufferedImage());


    			// Applying Mean Filter
    			OutputFilePath="images\\mean.pgm";
    			
    		    MeanFilter mean1=new MeanFilter();		    
  				mean1.setInFilePath(InputFilePath);
				mean1.setOutFilePath(OutputFilePath);
				mean1.PrintStatus=true;
				mean1.process(15,true); //15 is the standard	
				
				mseMen=mean1.getMsr();
				snrMen=mean1.getSnr();
				psnrMMen=mean1.getPsnrMaxValue();
				psnrPMen=mean1.getPsnrPeakValue();
				
				//show outputimage
				tpgm.setFilePath(OutputFilePath);
				tpgm.readImage();
				pbMean.setImage(tpgm.getBufferedImage());
								
				//Applying Median Filter
				OutputFilePath="images\\median.pgm";
    			
    		    MedianFilter m1=new MedianFilter();		    
  				m1.setInFilePath(InputFilePath);
				m1.setOutFilePath(OutputFilePath);
				m1.PrintStatus=true;
				m1.process(15,true); //15 is the standard	
				
				mseMed=m1.getMsr();
				snrMed=m1.getSnr();
				psnrMMed=m1.getPsnrMaxValue();
				psnrPMed=m1.getPsnrPeakValue();				
								
				//show outputimage
				tpgm.setFilePath(OutputFilePath);
				tpgm.readImage();
				pbMedian.setImage(tpgm.getBufferedImage());
				
				//Applying Fuzzy Filter
				OutputFilePath="images\\fuzzy.pgm";
    			
    		    FuzzyFilter f=new FuzzyFilter();		    
  				f.setInFilePath(InputFilePath);
				f.setOutFilePath(OutputFilePath);
				f.PrintStatus=true;
				f.process(2,true,10.0); //2 is the standard
				
				
				mseFuz=f.getMsr();
				snrFuz=f.getSnr();
				psnrMFuz=f.getPsnrMaxValue();
				psnrPFuz=f.getPsnrPeakValue();	
				
				//show outputimage
				tpgm.setFilePath(OutputFilePath);
				tpgm.readImage();
				pbFuzzy.setImage(tpgm.getBufferedImage());	
		

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Compare Images filtered by various filters");
        setForeground(new java.awt.Color(255, 0, 0));
        setIconImage((new ImageIcon("peslogo1.jpg")).getImage()) ;
        
        

        jInternalFrame1.setTitle("Input Image ");
        jInternalFrame1.setResizable(false);
        jInternalFrame1.setVisible(true);

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 289, Short.MAX_VALUE)
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 817, Short.MAX_VALUE)
        );

        jInternalFrame3.setTitle("Median filtered Image");
        jInternalFrame3.setResizable(false);
        jInternalFrame3.setVisible(true);

        javax.swing.GroupLayout jInternalFrame3Layout = new javax.swing.GroupLayout(jInternalFrame3.getContentPane());
        jInternalFrame3.getContentPane().setLayout(jInternalFrame3Layout);
        jInternalFrame3Layout.setHorizontalGroup(
            jInternalFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 284, Short.MAX_VALUE)
        );
        jInternalFrame3Layout.setVerticalGroup(
            jInternalFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 817, Short.MAX_VALUE)
        );

        jInternalFrame4.setTitle("Fuzzy filtered Image ");
        jInternalFrame4.setResizable(false);
        jInternalFrame4.setVisible(true);

        javax.swing.GroupLayout jInternalFrame4Layout = new javax.swing.GroupLayout(jInternalFrame4.getContentPane());
        jInternalFrame4.getContentPane().setLayout(jInternalFrame4Layout);
        jInternalFrame4Layout.setHorizontalGroup(
            jInternalFrame4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 299, Short.MAX_VALUE)
        );
        jInternalFrame4Layout.setVerticalGroup(
            jInternalFrame4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 817, Short.MAX_VALUE)
        );

        jInternalFrame2.setTitle("Mean filtered Image ");
        jInternalFrame2.setResizable(false);
        jInternalFrame2.setVisible(true);

        javax.swing.GroupLayout jInternalFrame2Layout = new javax.swing.GroupLayout(jInternalFrame2.getContentPane());
        jInternalFrame2.getContentPane().setLayout(jInternalFrame2Layout);
        jInternalFrame2Layout.setHorizontalGroup(
            jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 276, Short.MAX_VALUE)
        );
        jInternalFrame2Layout.setVerticalGroup(
            jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 817, Short.MAX_VALUE)
        );
        

        jButton1.setFont(new java.awt.Font("Monotype Corsiva", 0, 18)); 
        jButton1.setText("Mean Filter");
        jButton1.setToolTipText("Noise parameters and graph of MSE vs Iteration");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Monotype Corsiva", 0, 18)); 
        jButton2.setText("Median Filter");
        jButton2.setToolTipText("Noise parameters and graph of MSE vs Iteration");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Monotype Corsiva", 0, 18)); 
        jButton3.setText("Fuzzy Filter");
        jButton3.setToolTipText("Noise parameters and graphs of MSE , K vs Iteration");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(mcp);
        mcp.setLayout(layout);

        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jInternalFrame1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jInternalFrame2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                    .addComponent(jInternalFrame3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jInternalFrame4))
                .addContainerGap(95, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jInternalFrame4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jInternalFrame3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jInternalFrame2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jInternalFrame1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(54, 54, 54)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)))
                .addContainerGap())
        );
        SwingUtilities.updateComponentTreeUI(mcp);
        SwingUtilities.updateComponentTreeUI(this);
        pack();
    }
	//Fuzzy Filter
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
            java.awt.EventQueue.invokeLater(new Runnable() {
            	public void run() {
               		 new Parameters('z',mseFuz,snrFuz,psnrMFuz,psnrPFuz).setVisible(true);
            	}
        	});   
        		//Applying Fuzzy Filter
				OutputFilePath="images\\fuzzy.pgm";
    			
    		    FuzzyFilter f=new FuzzyFilter();		    
  				f.setInFilePath(InputFilePath);
				f.setOutFilePath(OutputFilePath);
				f.PrintStatus=true;
				f.process(15,false,10.0);
				
    }
	//Mean filter
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) { 	
 		   	java.awt.EventQueue.invokeLater(new Runnable() {
            	public void run() {
               		 new Parameters('m',mseMen,snrMen,psnrMMen,psnrPMen).setVisible(true);
            	}
        	});  
        	    // Applying Mean Filter
    			OutputFilePath="images\\mean.pgm";
    			
    		    MeanFilter mean1=new MeanFilter();		    
  				mean1.setInFilePath(InputFilePath);
				mean1.setOutFilePath(OutputFilePath);
				mean1.PrintStatus=true;
				mean1.process(15,false); //15 is the standard	
    }
	//Median filter
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
    		java.awt.EventQueue.invokeLater(new Runnable() {
            	public void run() {
               		 new Parameters('d',mseMed,snrMed,psnrMMed,psnrPMed).setVisible(true);
            	}
        	}); 
        		//Applying Median Filter
				OutputFilePath="images\\median.pgm";
    			
    		    MedianFilter m1=new MedianFilter();		    
  				m1.setInFilePath(InputFilePath);
				m1.setOutFilePath(OutputFilePath);
				m1.PrintStatus=true;
				m1.process(15,false); //15 is the standard
    }
    
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JInternalFrame jInternalFrame2;
    private javax.swing.JInternalFrame jInternalFrame3;
    private javax.swing.JInternalFrame jInternalFrame4;
    // End of variables declaration
    
        class MyContentPane extends JPanel  {
	 
	    Point2D point1 = new Point(0, 100); // = 10 ;
	    Point2D point2 = new Point(200, 400); // = 100 ;
	    Color fillColor1 = new Color(102, 255, 102) ;
	    Color fillColor2 = new Color(102, 102, 255);
	    boolean cyclicMode = true ;
	    
	  	public  MyContentPane() {
		    super() ;
		}
		public void paintComponent(Graphics g)  {
			super.paintComponent(g);
			Graphics2D g2D = (Graphics2D) g ;
			Paint gp = new GradientPaint(point1, fillColor1, point2, fillColor2, cyclicMode) ;
			g2D.setPaint(gp) ;
			g2D.fill(new Rectangle2D.Double(0, 0, getWidth(), getHeight())) ;
		}
	}
    
}