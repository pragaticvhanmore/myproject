abstract public class Filter{
	
	abstract public String getInFilePath();
	
	abstract public String getOutFilePath();
	
	abstract public void setInFilePath(String tFilePath);
	
	abstract public void setOutFilePath(String tFilePath);
	
	abstract public void process(int tIterations,boolean p);
}