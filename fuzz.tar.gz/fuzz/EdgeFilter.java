import java.lang.*;
import java.io.*;

public class EdgeFilter extends Filter
{
	private String InFilePath,OutFilePath;

	public final static float[] SOBEL_V = {
		-1,  0,  1,
		-2,  0,  2,
		-1,  0,  1,
	};
	public static float[] SOBEL_H = {
		-1, -2, -1,
		0,  0,  0,
		1,  2,  1,
	};

	protected float[] vEdgeMatrix = SOBEL_V;
	protected float[] hEdgeMatrix = SOBEL_H;
	
	public boolean PrintStatus=false;

	//constructor
	public EdgeFilter()
	{
		InFilePath="";
		OutFilePath="";
	}

	//get functions
	public String getInFilePath()
	{
		return(InFilePath);
	}
	
	public String getOutFilePath()
	{
		return(OutFilePath);
	}
	
	//set functions
	public void setInFilePath(String tFilePath)
	{
		InFilePath=tFilePath;
	}
	
	public void setOutFilePath(String tFilePath)
	{
		OutFilePath=tFilePath;
	}
	public void process(int tIterations,boolean p)
	{
		PGM imgin=new PGM();
		PGM imgout=new PGM();

		if(PrintStatus==true)
		{
			System.out.println(" EDGE FILTER \n");
			System.out.println(" Applying Edge Filter...");
		}
	
		//read input image
		imgin.setFilePath(InFilePath);
		if(!imgin.readImage())
			return;
	
		//set output-image header
		imgout.setFilePath(OutFilePath);
		imgout.setType("P5");
		imgout.setComment("#edge-filtered image");
		imgout.setDimension(imgin.getCols(),imgin.getRows());
		imgout.setMaxGray(imgin.getMaxGray());
		
		for(int t=1;t<=tIterations;t++)
		{
			
		 	int []arr=new int[imgin.getCols()];
		 	int []neighbour=new int[9];
		 	int min;
		 	for(int r=0;r<imgout.getRows();r++)
			{
				for(int c=0;c<imgout.getCols();c++)
				{
					int inval=imgin.getPixel(r,c); //get current pixel
	
					//get neighbourhood pixel intensity values
					
					neighbour[0]=imgin.getNeighbor(r,c,Globals.NW);
					neighbour[1]=imgin.getNeighbor(r,c,Globals.W );
					neighbour[2]=imgin.getNeighbor(r,c,Globals.SW);
					neighbour[3]=imgin.getNeighbor(r,c,Globals.S );
					neighbour[4]=imgin.getNeighbor(r,c,Globals.SE);
					neighbour[5]=imgin.getNeighbor(r,c,Globals.E);
					neighbour[6]=imgin.getNeighbor(r,c,Globals.NE);
					neighbour[7]=imgin.getNeighbor(r,c,Globals.N );
	
					arr=filterPixels(3,3,neighbour);
					min=arr[0];
					for(int k=1;k<arr.length;k++) 
					  if(min>arr[k]) min=arr[k];
					if(inval!=min)  
					   imgout.setPixel(r,c,min);
					else
					   imgout.setPixel(r,c,inval);
				}
			}
		 	//set outputimage as input to next iteration (if not last iteration)
			if(t!=tIterations)
			{
				for(int r=0;r<imgin.getRows();r++)
				{
					for(int c=0;c<imgin.getCols();c++)
					{
						imgin.setPixel(r,c,imgout.getPixel(r,c));
					}
				}
			}
		}
		//write output image
		imgout.writeImage();
		System.out.println(" Edge Filter Applied");
	}
	public void setVEdgeMatrix(float[] vEdgeMatrix) {
		this.vEdgeMatrix = vEdgeMatrix;
	}

	public float[] getVEdgeMatrix() {
		return vEdgeMatrix;
	}

	public void setHEdgeMatrix(float[] hEdgeMatrix) {
		this.hEdgeMatrix = hEdgeMatrix;
	}

	public float[] getHEdgeMatrix() {
		return hEdgeMatrix;
	}

	protected int[] filterPixels( int width, int height, int[] inPixels ) {
		int index = 0;
		int[] outPixels = new int[width * height];

		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				int r = 0, g = 0, b = 0;
				int rh = 0, gh = 0, bh = 0;
				int rv = 0, gv = 0, bv = 0;
				int a = inPixels[y*width+x] & 0xff000000;

				for (int row = -1; row <= 1; row++) {
					int iy = y+row;
					int ioffset;
					if (0 <= iy && iy < height)
						ioffset = iy*width;
					else
						ioffset = y*width;
					int moffset = 3*(row+1)+1;
					for (int col = -1; col <= 1; col++) {
						int ix = x+col;
						if (!(0 <= ix && ix < width))
							ix = x;
						int rgb = inPixels[ioffset+ix];
						float h = hEdgeMatrix[moffset+col];
						float v = vEdgeMatrix[moffset+col];

						r = (rgb & 0xff0000) >> 16;
						g = (rgb & 0x00ff00) >> 8;
						b = rgb & 0x0000ff;
						rh += (int)(h * r);
						gh += (int)(h * g);
						bh += (int)(h * b);
						rv += (int)(v * r);
						gv += (int)(v * g);
						bv += (int)(v * b);
					}
				}
				r = (int)(Math.sqrt(rh*rh + rv*rv) / 1.8);
				g = (int)(Math.sqrt(gh*gh + gv*gv) / 1.8);
				b = (int)(Math.sqrt(bh*bh + bv*bv) / 1.8);
				r = clamp(r);
				g = clamp(g);
				b = clamp(b);
				outPixels[index++] = a | (r << 16) | (g << 8) | b;
			}

		}
		return outPixels;
	}
	public static int clamp(int c) {
		if (c < 0)
			return 0;
		if (c > 255)
			return 255;
		return c;
	}
}