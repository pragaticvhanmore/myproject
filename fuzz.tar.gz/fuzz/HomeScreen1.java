import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.filechooser.*;
import javax.imageio.*;
import java.awt.geom.* ;
public class HomeScreen1 extends javax.swing.JFrame {
	
	MyContentPane mcp = new MyContentPane() ;
   
    /** Creates new form NewJFrame */
    public HomeScreen1() {
        initComponents();        
    }

    @SuppressWarnings("unchecked")
   
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Noise Reduction in Images using Fuzzy Filtering");
        setBounds(new java.awt.Rectangle(350, 100, 0, 0));
        setResizable(false);
        
		mcp = new MyContentPane() ;
		Container container = getContentPane() ;
		container.add(mcp) ;

        jLabel1.setFont(new java.awt.Font("Monotype Corsiva", 1, 28)); 
        jLabel1.setForeground(new Color(0, 0, 125));
        jLabel1.setText("Noise Reduction in Images using Fuzzy Filtering");

        jLabel2.setFont(new java.awt.Font("Mongolian Baiti", 1, 15));
        jLabel2.setForeground(new Color(0, 0, 155));
        jLabel2.setText("Kulkarni E.W.");

        jLabel3.setFont(new java.awt.Font("Mongolian Baiti", 1, 15)); 
        jLabel3.setForeground(new Color(0, 0, 155));
        jLabel3.setText("College:- Walchand College Of Engineering");

        jLabel5.setFont(new java.awt.Font("Mongolian Baiti", 1, 17)); 
        jLabel5.setForeground(new Color(0, 0, 155));
        jLabel5.setText("Laxmi Nail                2015BIT207");

        jLabel6.setFont(new java.awt.Font("Mongolian Baiti", 1, 17)); 
        jLabel6.setForeground(new Color(0, 0, 155));
        jLabel6.setText("Pragati Vhanmore                    2015BIT211");

        jLabel7.setFont(new java.awt.Font("Mongolian Baiti", 1, 17));
        jLabel7.setForeground(new Color(0, 0, 155));
        jLabel7.setText("Omnath Kothwade                    2015BIT217");

        jButton1.setFont(new java.awt.Font("Calibri", 1, 18)); 
        jButton1.setText("Continue");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(mcp);
        mcp.setLayout(layout);
        
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 599, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(75, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(123, 123, 123)
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE)
                .addGap(116, 116, 116))
            .addGroup(layout.createSequentialGroup()
                .addGap(226, 226, 226)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(284, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(191, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 347, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(57, 57, 57)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(123, 123, 123)
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 586, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(123, 123, 123)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 586, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addGap(29, 29, 29)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE))
                .addContainerGap())
        );
        SwingUtilities.updateComponentTreeUI(this);
        pack();
    }
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
             	  dispose();
      	          java.awt.EventQueue.invokeLater(new Runnable() {
            			public void run() {
                			FrontEnd fe = new FrontEnd() ;
                			fe.setVisible(true);
                			SwingUtilities.updateComponentTreeUI(fe);
            			}
        	    	});
        	    	SwingUtilities.updateComponentTreeUI(this);
    }
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    // End of variables declaration
    
    class MyContentPane extends JPanel  {
    	
	    Point2D point1 = new Point(0, 100); // = 10 ;
	    Point2D point2 = new Point(200, 400); // = 100 ;
	    Color fillColor1 = new Color(102, 255, 102) ;
	    Color fillColor2 = new Color(102, 102, 255);
	    boolean cyclicMode = true ;
	    
	  public  MyContentPane() {
		    super() ;
		}
	public void paintComponent(Graphics g)  {
		
			super.paintComponent(g);
		    Graphics2D g2D = (Graphics2D) g ;
			Paint gp = new GradientPaint(point1, fillColor1, point2, fillColor2, cyclicMode) ;
			g2D.setPaint(gp) ;
			g2D.fill(new Rectangle2D.Double(0, 0, getWidth(), getHeight())) ;
	}
 }
}