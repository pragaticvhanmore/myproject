//FuzzyFilter.java

import java.lang.*;
import java.io.*;
import javax.swing.*;

public class FuzzyFilter
{
	private String InFilePath,OutFilePath;
	public boolean PrintStatus=false;
	private double meanSquareError,snr,psnrMaxValue,psnrPeakValue;
	private double[] kValue;
	private double[] MSE;
	
	//constructor
	public FuzzyFilter()
	{
		InFilePath="";
		OutFilePath="";
	}

	//get functions
	public String getInFilePath()
	{
		return(InFilePath);
	}
	
	public String getOutFilePath()
	{
		return(OutFilePath);
	}
	
	//set functions
	public void setInFilePath(String tFilePath)
	{
		InFilePath=tFilePath;
	}
	
	public void setOutFilePath(String tFilePath)
	{
		OutFilePath=tFilePath;
	}

	public void process(int tFuzzyDepth, boolean p, double a)
	{
		PGM imgin=new PGM();
		PGM imgout=new PGM();
		PGM imgdef=new PGM();
		
		int nrows, ncols;
	    int img1[][], img2[][];
        double  peak=0, signal=0, noise=0, mse=0;
        kValue=new double[tFuzzyDepth];
		MSE=new double[tFuzzyDepth];
		
		if(PrintStatus==true && p==true)
		{
			System.out.println("\n FUZZY FILTER \n");
			System.out.println(" Applying Fuzzy Filter...");
		}
		
		//read input image
		imgin.setFilePath(InFilePath);
		if(!imgin.readImage())
			return; // if the image cannot be read, readImage() in PGM class 
					// will display the error
			
		imgdef.setFilePath(InFilePath);
		if(!imgdef.readImage())
			return;
		
        nrows=imgin.getRows(); 
        ncols=imgin.getCols();
        img1 = new int[nrows][ncols];
        img2 = new int[nrows][ncols];		
		
	  	for(int r=0;r<nrows;r++)
	  	{
    		for(int c=0;c<ncols;c++)
    		{
    			img1[r][c]=imgin.getPixel(r,c);
    		}
    	}
		
		//set output-image header
		imgout.setFilePath(OutFilePath);
		imgout.setType("P5");
		imgout.setComment("#fuzzy-filtered image");
		imgout.setDimension(imgin.getCols(),imgin.getRows());
		imgout.setMaxGray(imgin.getMaxGray());
		
		//fuzzy image filtering
		int K=-1,prevK=0,L=imgin.getMaxGray();
		int neighbor[]=new int[8];
		int simpderiv[][]=new int[3][8];
		double fofxsmall[][]=new double[3][8];
		double fuzzyderiv[]=new double[8];
		double fofxpositive[]=new double[8];
		double fofxnegative[]=new double[8];
		double positivetruthness[]=new double[8];
		double negativetruthness[]=new double[8];
		double delta,fK;
		
		int samecount=0;
		boolean stop=false;
		
		int iter=1;
		do
		{
			//find parameter K
			
			int dim=9;
			int kvals[]=new int[9*9]; //divide image into mxn blocks
			double cnt=0.0; //block count
			double h,sumh=0.0,meanh; //homogenity
			double sd,sumsd=0.0,meansd; //standard deviation
			double uM; //slope
			double alpha=a; //amplifaction factor(10.0 by default)
			double sigma; //effective noise-level
			
			//for each block
			for(int m=0;m<imgin.getRows();m=m+dim)
			{
				for(int n=0;n<imgin.getCols();n=n+dim)
				{
					//get pixelvalues
					for(int tr=m,t=0;tr<m+dim;tr++)
					{
						for(int tc=n;tc<n+dim;tc++)
						{
							kvals[t]=imgin.getPixel(tr,tc);
							t=t+1;
						}
					}
					
					//find homogenity
					int maxval=kvals[0];
					int minval=kvals[0];
					for(int t=1;t<dim*dim;t++)
					{
						if(maxval<kvals[t]) maxval=kvals[t];
						if(minval>kvals[t]) minval=kvals[t];
					}
					h=1.0-((double)(maxval-minval)/(double)L);
					sumh=sumh+h;
					
					//find standard deviation
					int sum=0;
					double mean,dsum=0;
					
					for(int t=0;t<dim*dim;t++) 
						sum=sum+kvals[t]; //find sum
					
					mean=(double)sum/(double)(dim*dim);
					
					for(int t=0;t<dim*dim;t++) 
						dsum=dsum+((kvals[t]-mean)*(kvals[t]-mean));
					
					sd=Math.sqrt(dsum/((dim*dim)-1));
					sumsd=sumsd+sd;
					
					cnt=cnt+1.0;
				}
			}
			meanh=sumh/cnt;
			meansd=sumsd/cnt;
			uM=sumsd/cnt;
			
			sigma=(1-meanh)*uM; //effective noise-level
			
			fK=alpha*sigma;// adaptive factor
			
			K=(int)fK;
			prevK=K; 
			if(K==prevK)//true
			{
				samecount=samecount+1;//0+1
				if(samecount==tFuzzyDepth)//tfuzzydepth=2
				{
					if(PrintStatus==true && p==true)
					{
						System.out.println(" \n [K="+K+" is >= "+tFuzzyDepth+" -times ]...");
					}
					stop=true;
					break;
				}
			}
			else samecount=0;
			
			if(PrintStatus==true && p==true)
			{
				System.out.println(" Iteration : "+iter+" (K="+K+")...");
			}
			
			//for each pixel
			for(int r=0;r<imgin.getRows();r++)
			{
				for(int c=0;c<imgin.getCols();c++)
				{
					int inval=imgin.getPixel(r,c); //current pixel intensity value
					
					//get neighborhood pixel intensity values
					neighbor[0]=imgin.getNeighbor(r,c,Globals.NW);
					neighbor[1]=imgin.getNeighbor(r,c,Globals.W );
					neighbor[2]=imgin.getNeighbor(r,c,Globals.SW);
					neighbor[3]=imgin.getNeighbor(r,c,Globals.S );
					neighbor[4]=imgin.getNeighbor(r,c,Globals.SE);
					neighbor[5]=imgin.getNeighbor(r,c,Globals.E );
					neighbor[6]=imgin.getNeighbor(r,c,Globals.NE);
					neighbor[7]=imgin.getNeighbor(r,c,Globals.N );
					
					//fuzzy derivative estimation
					
					//calc simple derivative of (r,c)
					for(int t=0;t<8;t++) simpderiv[0][t]=neighbor[t]-inval;
					
					//calc simple derivative of perpendicular point-1
					simpderiv[1][0]=imgin.getPixel(r-1 +1,c-1 -1)-imgin.getPixel(r+1,c-1);
					simpderiv[1][1]=imgin.getPixel(r   +1,c-1   )-imgin.getPixel(r+1,c  );
					simpderiv[1][2]=imgin.getPixel(r+1 +1,c-1 +1)-imgin.getPixel(r+1,c+1);
					simpderiv[1][3]=imgin.getPixel(r+1   ,c   +1)-imgin.getPixel(r  ,c+1);
					simpderiv[1][4]=imgin.getPixel(r+1 -1,c+1 +1)-imgin.getPixel(r-1,c+1);
					simpderiv[1][5]=imgin.getPixel(r   -1,c+1   )-imgin.getPixel(r-1,c  );
					simpderiv[1][6]=imgin.getPixel(r-1 -1,c+1 -1)-imgin.getPixel(r-1,c-1);
					simpderiv[1][7]=imgin.getPixel(r-1   ,c   -1)-imgin.getPixel(r  ,c-1);
					
					//calc simple derivative of perpendicular point-2
					simpderiv[2][0]=imgin.getPixel(r-1 -1,c-1 +1)-imgin.getPixel(r-1,c+1);
					simpderiv[2][1]=imgin.getPixel(r   -1,c-1   )-imgin.getPixel(r-1,c  );
					simpderiv[2][2]=imgin.getPixel(r+1 -1,c-1 -1)-imgin.getPixel(r-1,c-1);
					simpderiv[2][3]=imgin.getPixel(r+1   ,c   -1)-imgin.getPixel(r  ,c-1);
					simpderiv[2][4]=imgin.getPixel(r+1 +1,c+1 -1)-imgin.getPixel(r+1,c-1);
					simpderiv[2][5]=imgin.getPixel(r   +1,c+1   )-imgin.getPixel(r+1,c  );
					simpderiv[2][6]=imgin.getPixel(r-1 +1,c+1 +1)-imgin.getPixel(r+1,c+1);
					simpderiv[2][7]=imgin.getPixel(r-1   ,c   +1)-imgin.getPixel(r  ,c+1);
					
					//calc membership value for 'small' fuzzy set
					for(int t=0;t<8;t++)
					{
						fofxsmall[0][t]=SmallFuzzySet.fofx(simpderiv[0][t],K);
						fofxsmall[1][t]=SmallFuzzySet.fofx(simpderiv[1][t],K);
						fofxsmall[2][t]=SmallFuzzySet.fofx(simpderiv[2][t],K);
					}
					
					//calc fuzzy derivative by applying fuzzy rule for 'small' fuzzy set
					for(int t=0;t<8;t++)
					{
						fuzzyderiv[t]=SmallFuzzySet.ApplyRule(fofxsmall[0][t],fofxsmall[1][t],fofxsmall[2][t]);
					}
					
					//fuzzy smoothing
					
					//calc membership values for 'positive' and 'negative' fuzzy sets
					for(int t=0;t<8;t++)
					{
						fofxpositive[t]=PositiveFuzzySet.fofx(simpderiv[0][t],L);
						fofxnegative[t]=NegativeFuzzySet.fofx(simpderiv[0][t],L);
					}
					
					//calc truthness of 'positive' and 'negative' fuzzy sets by applying fuzzy rules
					for(int t=0;t<8;t++)
					{
						positivetruthness[t]=PositiveFuzzySet.ApplyRule(fuzzyderiv[t],fofxpositive[t]);
						negativetruthness[t]=NegativeFuzzySet.ApplyRule(fuzzyderiv[t],fofxnegative[t]);
					}
					
					//calc correction term (defuzzification)
					delta=0.0;
					for(int t=0;t<8;t++)
					{
						delta=delta+(positivetruthness[t]-negativetruthness[t]);
					}
					delta=((double)L/8.0)*delta;
					
					int outval=inval+(int)delta;
					
					imgout.setPixel(r,c,outval);
					img2[r][c]=imgout.getPixel(r,c);
					
					signal += img1[r][c] * img1[r][c];
        			noise += (img1[r][c] - img2[r][c]) * (img1[r][c] - img2[r][c]);
        			if (peak < img1[r][c])
          					peak = img1[r][c];
				}
			}

			MSE[iter-1] = noise/(nrows*ncols);
			signal=0;
			peak=0;
			noise=0;
			
			//set outputimage as input to next iteration
			for(int r=0;r<imgin.getRows();r++)
			{
				for(int c=0;c<imgin.getCols();c++)
				{
					imgin.setPixel(r,c,imgout.getPixel(r,c));
				}
			}
			kValue[iter-1]=(double)K;
			iter++;
		}while(stop==false);
		
		if(PrintStatus==true && p==true)
		{
			System.out.println(" Fuzzy Filter Applied");
		}
	
		//write output image
		if(p==true)
			imgout.writeImage();
		else
			drawGraph(a);
		
		if(p==true)
		{
		
		//calculating PSNR	 
    	for(int r=0;r<nrows;r++){
    		for(int c=0;c<ncols;c++){
    			img2[r][c]=imgout.getPixel(r,c);
    		}
    	}
    	signal = noise = peak = 0;
    	for (int i=0; i<nrows; i++) {
      		for (int j=0; j<ncols; j++) {
        		signal += img1[i][j] * img1[i][j];
        		noise += (img1[i][j] - img2[i][j]) * (img1[i][j] - img2[i][j]);
        		if (peak < img1[i][j])
          			peak = img1[i][j];
      		}
    	}
    	mse = noise/(nrows*ncols); // Mean square error
		System.out.println(" Noise Parameters : \n");
    	System.out.println(" Mean Square Error (MSE)     : " + mse);
    	System.out.println(" Signal to noise ratio (SNR) : " + 10*log10(signal/noise));
    	System.out.println(" PSNR (max = 255)            : " + (10*log10(255*255/mse)));
    	System.out.println(" PSNR (max = "+ peak +")          : " + 10*log10((peak*peak)/mse));	
    	System.out.println();
    	
    	meanSquareError=mse;
    	snr=10*log10(signal/noise);
    	psnrMaxValue=(10*log10(255*255/mse));
    	psnrPeakValue=10*log10((peak*peak)/mse);	
    	}
	} 
  public static double log10(double x) {
    return Math.log(x)/Math.log(10);
  }
  //get functions to get Noise parameters		
  public double getMsr(){
  	return meanSquareError;
  }
  public double getSnr(){
  	return snr;
  }
  public double getPsnrMaxValue(){
  	return psnrMaxValue;
  }
  public double getPsnrPeakValue(){
  	return psnrPeakValue;
  }
  public void drawGraph(double a){
  	    
  	    // graph of K vs Iteration
  	    JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.add(new GraphingData(kValue,'z'));
        f.setSize(600,600);
        f.setLocation(300,100);
        f.setVisible(true);
        f.setResizable(false);
        f.setTitle("K vs Iteration - Fuzzy Filter (alpha = "+a+")");
        
   		// graph of MSE vs Iteration
  	    JFrame f2 = new JFrame();
        f2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f2.add(new GraphingData(MSE,'z'));
        f2.setSize(600,600);
        f2.setLocation(300,100);
        f2.setVisible(true);
        f2.setResizable(false);
        f2.setTitle("MSE vs Iteration - Fuzzy Filter (alpha = "+a+")");   		     
  }
}	