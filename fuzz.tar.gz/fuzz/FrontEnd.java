import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.filechooser.*;
import javax.imageio.*;
import java.awt.geom.* ;

public class FrontEnd extends javax.swing.JFrame {
    
   	 MyPictureBox pbInput;
	MyPictureBox pbOutput;
	
	String InputFilePath;
	String OutputFilePath;
	String tempFilePath="";
	
	MyContentPane mcp = new MyContentPane() ;
	
	static boolean flag=false;
	
    /** Creates new form FrontEnd */
    
    public FrontEnd() {
    	
		super() ;
		
		pbInput=new MyPictureBox();
		pbOutput=new MyPictureBox();
	
		InputFilePath="";
		OutputFilePath="";
		this.initComponents();
        		
    }

    @SuppressWarnings("unchecked")
    
    private void initComponents() {
    	
        OutFrm = new javax.swing.JInternalFrame();
        InFrm = new javax.swing.JInternalFrame();
        
        MeanBut = new javax.swing.JButton();
        MedBut = new javax.swing.JButton();
        FuzzyBut = new javax.swing.JButton();
        EdgeBut = new javax.swing.JButton();
        CompBut = new javax.swing.JButton();
        
        jLabel1 = new javax.swing.JLabel();
        
        jMenuBar1 = new javax.swing.JMenuBar();
        File = new javax.swing.JMenu();
        Open = new javax.swing.JMenuItem();
        Exit = new javax.swing.JMenuItem();
        
        Filter = new javax.swing.JMenu();
        MeanMen = new javax.swing.JMenuItem();
        MedianMen = new javax.swing.JMenuItem();
        FuzzyMen = new javax.swing.JMenuItem();
        EdgeMen = new javax.swing.JMenuItem();
        
        Help = new javax.swing.JMenu();
		opt1 = new javax.swing.JMenuItem();
		opt2 = new javax.swing.JMenuItem();
		noiseHelp = new javax.swing.JMenuItem();
		meanHelp = new javax.swing.JMenuItem();
		medHelp = new javax.swing.JMenuItem();
		edHelp = new javax.swing.JMenuItem();
		fuzHelp = new javax.swing.JMenuItem();
		paramHelp = new javax.swing.JMenuItem();
		
		mcp = new MyContentPane() ;
		Container container = getContentPane() ;
		container.add(mcp) ;
		
	       	pbInput.setBounds(0,-22,297,450);
		InFrm.getContentPane().add(pbInput);
		
		pbOutput.setBounds(0,-22,297,454);
		OutFrm.getContentPane().add(pbOutput);
		
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Noise Reduction in Images using Fuzzy Filtering");        
        setIconImage((new ImageIcon("peslogo1.jpg")).getImage()) ;

        OutFrm.setTitle("...                      Output Image                                                                                                             ");
        OutFrm.setVisible(true);

        javax.swing.GroupLayout OutFrmLayout = new javax.swing.GroupLayout(OutFrm.getContentPane());
        OutFrm.getContentPane().setLayout(OutFrmLayout);
        OutFrmLayout.setHorizontalGroup(
            OutFrmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 298, Short.MAX_VALUE)
        );
        OutFrmLayout.setVerticalGroup(
            OutFrmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 483, Short.MAX_VALUE)
        );

        MeanBut.setFont(new java.awt.Font("Monotype Corsiva", 2, 20));
        MeanBut.setText("Mean Filter");
        MeanBut.setToolTipText("Replaces each pixel value in an image with the mean \n(`average') value of its neighbours, including itself");
        MeanBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MeanButActionPerformed(evt);
            }
        });

        MedBut.setFont(new java.awt.Font("Monotype Corsiva", 2, 20));
        MedBut.setText("Median Filter");
        MedBut.setToolTipText("Replaces each pixel value in an image with the middle value of its \nneighbours, including itself");
        MedBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedButActionPerformed(evt);
            }
        });

        FuzzyBut.setFont(new java.awt.Font("Monotype Corsiva", 2, 20));
        FuzzyBut.setText("Fuzzy Filter");
        FuzzyBut.setToolTipText("Averages a pixel using other pixel values from its neighbourhood, \nbut simultaneously takes care of important image structures such as edges");
        FuzzyBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FuzzyButActionPerformed(evt);
            }
        });


        EdgeBut.setFont(new java.awt.Font("Monotype Corsiva", 2, 20));
        EdgeBut.setText("Edge Filter");
        EdgeBut.setToolTipText("Identifies and locates sharp discontinuities in an image");
        EdgeBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EdgeButActionPerformed(evt);
            }
        });
        
        
        CompBut.setFont(new java.awt.Font("Monotype Corsiva", 2, 20));
        CompBut.setText("Compare Filters");
        CompBut.setToolTipText("Compares the Filters and their Noise parameters");
        CompBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CompButActionPerformed(evt);
            }
        });
        
        InFrm.setResizable(false);
        InFrm.setTitle("...                             Input Image                                                                        ");
        InFrm.setVisible(true);

        javax.swing.GroupLayout InFrmLayout = new javax.swing.GroupLayout(InFrm.getContentPane());
        InFrm.getContentPane().setLayout(InFrmLayout);
        InFrmLayout.setHorizontalGroup(
            InFrmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 297, Short.MAX_VALUE)
        );
        InFrmLayout.setVerticalGroup(
            InFrmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 478, Short.MAX_VALUE)
        );

        

        jLabel1.setFont(new java.awt.Font("Aharoni", 1, 36));
        jLabel1.setText("Noise Reduction in Images using Fuzzy Filtering");
        jLabel1.setIcon(new ImageIcon("peslogo.jpg"));
        jLabel1.setHorizontalTextPosition(JLabel.RIGHT);
        jLabel1.setIconTextGap(10) ;
		jLabel1.setForeground(new Color(0, 0, 55));
        jMenuBar1.setBackground(new java.awt.Color(0, 0, 0));

        File.setBackground(new java.awt.Color(0, 76, 89));
        File.setForeground(new java.awt.Color(255, 255, 255));
        File.setText("File");

        Open.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        Open.setText("Open Image");
        Open.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OpenActionPerformed(evt);
            }
        });
        File.add(Open);

        Exit.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_MASK));
        Exit.setText("Exit");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });
        File.add(Exit);
        
        jMenuBar1.add(File);

        Filter.setBackground(new java.awt.Color(0, 0, 0));
        Filter.setForeground(new java.awt.Color(255, 255, 255));
        Filter.setText("Filter");

        MeanMen.setText("Mean Filter");
        MeanMen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MeanMenActionPerformed(evt);
            }});
        Filter.add(MeanMen);

        MedianMen.setText("Median Filter");
        MedianMen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedianMenActionPerformed(evt);
            }});
        Filter.add(MedianMen);
       

        FuzzyMen.setText("Fuzzy Filter");
        FuzzyMen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FuzzyMenActionPerformed(evt);
            }});
        Filter.add(FuzzyMen);

        EdgeMen.setText("Edge Detector");
        EdgeMen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EdgeMenActionPerformed(evt);
             }});
        Filter.add(EdgeMen);
      

        jMenuBar1.add(Filter);

        Help.setBackground(new java.awt.Color(0, 0, 0));
        Help.setForeground(new java.awt.Color(255, 255, 255));
        Help.setText("Help");
        
        opt1.setText("Help Files");
        opt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opt1ActionPerformed(evt);
             }});
        Help.add(opt1);
        
        opt2.setText("Credits");
        opt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opt2ActionPerformed(evt);
             }});
        Help.add(opt2);
        
        noiseHelp.setText("Noise in Images");
        noiseHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noiseHelpActionPerformed(evt);
             }});
        Help.add(noiseHelp);
        
        meanHelp.setText("About Mean Filter");
        meanHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                meanHelpActionPerformed(evt);
             }});
        Help.add(meanHelp);
        
        medHelp.setText("About Median Filter");
        medHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                medHelpActionPerformed(evt);
             }});
        Help.add(medHelp);
    
    	edHelp.setText("About Edge Filter");
        edHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edHelpActionPerformed(evt);
             }});
        Help.add(edHelp);
        
        fuzHelp.setText("About Fuzzy Filter");
        fuzHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fuzHelpActionPerformed(evt);
             }});
        Help.add(fuzHelp);

		paramHelp.setText("Noise Parameters");
        paramHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paramHelpActionPerformed(evt);
             }});
        Help.add(paramHelp);
		            
        jMenuBar1.add(Help);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(mcp);
        mcp.setLayout(layout);
                
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(154, 154, 154)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                  //  .addComponent(new JLabel("jLabel1"), javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(InFrm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(100, 100, 100)
                        .addComponent(OutFrm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 93, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
              //   	.addComponent(new JLabel("MeanBut"), javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                    .addComponent(MeanBut, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                    .addComponent(MedBut, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                    .addComponent(FuzzyBut, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                    .addComponent(EdgeBut, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                    .addComponent(CompBut, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(43, 43, 43))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(191, 191, 191)
                        .addComponent(MeanBut, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(MedBut, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(47, 47, 47)
                        .addComponent(FuzzyBut, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49)
                        .addComponent(EdgeBut, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(CompBut, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(OutFrm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(InFrm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(63, Short.MAX_VALUE))
        );
        SwingUtilities.updateComponentTreeUI(mcp);
        SwingUtilities.updateComponentTreeUI(this);
        pack();
    }

    private void OpenActionPerformed(java.awt.event.ActionEvent evt) {
		
		    JFileChooser tFileChooser=new JFileChooser("images");
			tFileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			int tResult=tFileChooser.showOpenDialog(this);

			if(tResult==JFileChooser.APPROVE_OPTION)
			{
				InputFilePath=tFileChooser.getSelectedFile().toString();
				PGM tpgm=new PGM();
				tpgm.setFilePath(InputFilePath);
				if(tpgm.readImage())
				{
					pbInput.setImage(tpgm.getBufferedImage());
	    			flag=true;
	
					OutputFilePath="images\\dot.pgm";
					showOpImage();
				}
			}
    }

    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {
    			dispose();
    }
    
    private void opt1ActionPerformed(java.awt.event.ActionEvent evt){
    		
    		JFileChooser tFileChooser=new JFileChooser("helpFiles");
			tFileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			int tResult=tFileChooser.showOpenDialog(this);

			if(tResult==JFileChooser.APPROVE_OPTION)
			{
				try{
					InputStream f=new FileInputStream(tFileChooser.getSelectedFile().toString());
					int size=f.available();
					for(int i=0;i<size;i++){
						System.out.print((char)f.read());
					}
					f.close();
				}
				catch(IOException e){	
				}
			}
    }
     private void opt2ActionPerformed(java.awt.event.ActionEvent evt){    
        
            java.awt.EventQueue.invokeLater(new Runnable() {
  		          public void run() {
        	        new Credits().setVisible(true);
            	  }
       		 });
      } 
     private void noiseHelpActionPerformed(java.awt.event.ActionEvent evt){    
        
            java.awt.EventQueue.invokeLater(new Runnable() {
  		          public void run() {
        	        new HelpScreen('n').setVisible(true);
            	  }
       		 });
      }
      private void meanHelpActionPerformed(java.awt.event.ActionEvent evt){    
        
            java.awt.EventQueue.invokeLater(new Runnable() {
  		          public void run() {
        	        new HelpScreen('m').setVisible(true);
            	  }
       		 });
      }
      private void medHelpActionPerformed(java.awt.event.ActionEvent evt){    
        
            java.awt.EventQueue.invokeLater(new Runnable() {
  		          public void run() {
        	        new HelpScreen('d').setVisible(true);
            	  }
       		 });
      }
     private void fuzHelpActionPerformed(java.awt.event.ActionEvent evt){    
        
            java.awt.EventQueue.invokeLater(new Runnable() {
  		          public void run() {
        	        new HelpScreen('z').setVisible(true);
            	  }
       		 });
      }
     private void edHelpActionPerformed(java.awt.event.ActionEvent evt){    
        
            java.awt.EventQueue.invokeLater(new Runnable() {
  		          public void run() {
        	        new HelpScreen('e').setVisible(true);
            	  }
       		 });
      }
     private void paramHelpActionPerformed(java.awt.event.ActionEvent evt){    
        
            java.awt.EventQueue.invokeLater(new Runnable() {
  		          public void run() {
        	        new HelpScreen('p').setVisible(true);
            	  }
       		 });
      }

    private void MeanButActionPerformed(java.awt.event.ActionEvent evt) {
    	
    	     if(!flag)
    	     {  
     	     	OpenActionPerformed(evt);
    	     }
    	     if(flag)
    	     {
				getAndSetOutFilePath();	
    			
    		    MeanFilter mean1=new MeanFilter();		    
  				mean1.setInFilePath(InputFilePath);
				mean1.setOutFilePath(OutputFilePath);
				mean1.PrintStatus=true;
				mean1.process(15,true); //15 is the standard	
				
				showOpImage();
			}
    }

    private void MedButActionPerformed(java.awt.event.ActionEvent evt) {
    	
    	     if(!flag)
    	     {
    	     	OpenActionPerformed(evt);
    	     }
			 if(flag)
			 {    	
				getAndSetOutFilePath();	
				    	
			    MedianFilter med=new MedianFilter();
				med.setInFilePath(InputFilePath);
				med.setOutFilePath(OutputFilePath);
				med.PrintStatus=true;
				med.process(15,true); //15 is the standard
				
				showOpImage();
			}
    }

    private void FuzzyButActionPerformed(java.awt.event.ActionEvent evt) {
    	
        		
        	 if(!flag)
    	     {
    	     	OpenActionPerformed(evt);
    	     }
        	 if(flag)
        	 {	
				getAndSetOutFilePath();	
				
				FuzzyFilter fuzzy1=new FuzzyFilter();
				fuzzy1.setInFilePath(InputFilePath);
				fuzzy1.setOutFilePath(OutputFilePath);
				fuzzy1.PrintStatus=true;
				fuzzy1.process(2,true,10.0); // 2 is the standard
				
				showOpImage();
			}
    }

    private void EdgeButActionPerformed(java.awt.event.ActionEvent evt) {
            
             if(!flag)
    	     {
    	     	OpenActionPerformed(evt);
    	     }
             if(flag)
             {
            	getAndSetOutFilePath();	
				
				EdgeFilter e=new EdgeFilter();
				e.setInFilePath(InputFilePath);
				e.setOutFilePath(OutputFilePath);
				e.PrintStatus=true;
				e.process(1,true); // 1 is the standard
				
				showOpImage();
			}
    }

    private void CompButActionPerformed(java.awt.event.ActionEvent evt){
    	
    	
    		JFileChooser tFileChooser=new JFileChooser("images");
			tFileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			int tResult=tFileChooser.showOpenDialog(this);
			
			if(tResult==JFileChooser.APPROVE_OPTION)
			{
				tempFilePath=tFileChooser.getSelectedFile().toString();
				PGM tpgm=new PGM();
				tpgm.setFilePath(tempFilePath);
				if(tpgm.readImage())
				{	
    				java.awt.EventQueue.invokeLater(new Runnable() {
            			public void run() {
                			new CompareImages(tempFilePath).setVisible(true);
            			}
        			});
        		}
        	}
    }
    
    private void MeanMenActionPerformed(java.awt.event.ActionEvent evt){
    
    			MeanButActionPerformed(evt);
    }
    
    private void MedianMenActionPerformed(java.awt.event.ActionEvent evt){
    	
    			MedButActionPerformed(evt);			
    }
    
    private void FuzzyMenActionPerformed(java.awt.event.ActionEvent evt){
    	
    			FuzzyButActionPerformed(evt);
    }
    
    private void EdgeMenActionPerformed(java.awt.event.ActionEvent evt){
    	
    			EdgeButActionPerformed(evt);
    }
    
    private void getAndSetOutFilePath(){
    	
    	        JFileChooser tFileChooser=new JFileChooser("images");
				tFileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
				tFileChooser.setSelectedFile(new File("images\\out.pgm"));
				int tResult=tFileChooser.showSaveDialog(this);	
				
				OutputFilePath=tFileChooser.getSelectedFile().toString();
    }
    private void showOpImage(){
    			PGM tpgm=new PGM();
				tpgm.setFilePath(OutputFilePath);
				tpgm.readImage();
				pbOutput.setImage(tpgm.getBufferedImage());
				SwingUtilities.updateComponentTreeUI(pbOutput);
				SwingUtilities.updateComponentTreeUI(pbInput);
				SwingUtilities.updateComponentTreeUI(InFrm);
				SwingUtilities.updateComponentTreeUI(this);
    }
        
    private javax.swing.JButton CompBut;
    private javax.swing.JButton EdgeBut;
    private javax.swing.JMenuItem EdgeMen;
    private javax.swing.JMenuItem Exit;
    private javax.swing.JMenu File, Filter;
    private javax.swing.JButton FuzzyBut;
    private javax.swing.JMenuItem FuzzyMen;
    private javax.swing.JMenu Help;
    private javax.swing.JInternalFrame InFrm;
    private javax.swing.JButton MeanBut;
    private javax.swing.JMenuItem MeanMen;
    private javax.swing.JButton MedBut;
    private javax.swing.JMenuItem MedianMen;
    private javax.swing.JMenuItem Open;
    private javax.swing.JInternalFrame OutFrm;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem opt1;
    private javax.swing.JMenuItem opt2;
    private javax.swing.JMenuItem meanHelp;
    private javax.swing.JMenuItem medHelp;
    private javax.swing.JMenuItem edHelp;
    private javax.swing.JMenuItem fuzHelp;
    private javax.swing.JMenuItem paramHelp;
    private javax.swing.JMenuItem noiseHelp;
    // End of variables declaration
    
    class MyContentPane extends JPanel  {

	    Point2D point1 = new Point(0, 100); // = 10 ;
	    Point2D point2 = new Point(200, 400); // = 100 ;
	    Color fillColor1 = new Color(102, 255, 102) ;
	    Color fillColor2 = new Color(102, 102, 255);
	    boolean cyclicMode = true ;
	    
	  	public  MyContentPane() {
		    super() ;
		}
		public void paintComponent(Graphics g)  {
			super.paintComponent(g);
			Graphics2D g2D = (Graphics2D) g ;
			Paint gp = new GradientPaint(point1, fillColor1, point2, fillColor2, cyclicMode) ;
			g2D.setPaint(gp) ;
			g2D.fill(new Rectangle2D.Double(0, 0, getWidth(), getHeight())) ;
		}
	}
}