import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;
import javax.swing.*;

public class GraphingData extends JPanel {
    
    double[] data;
    String x;
    String y;
    boolean isFuzz;
    
    final int PAD = 20;
    
    public GraphingData(double d[], char f){
    	
    	data=new double[d.length];
    	for(int i=0;i<d.length;i++)
    		data[i]=d[i];
    
    	switch(f){
    		case 'm': 
    		case 'd': 
    				x = new String("Iteration");
    				y = new String("MSE");
    				isFuzz=false;
    				break;
    		case 'z':
    				x = new String("Iteration");
    				y = new String("Y-axis");
    				isFuzz=true;
    				break;
    	}
    }

    protected void paintComponent(Graphics g) {
    	  
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth();
        int h = getHeight();
               
        // Draw ordinate.
        g2.draw(new Line2D.Double(PAD, PAD, PAD, h-PAD));
        // Draw abcissa.
        g2.draw(new Line2D.Double(PAD, h-PAD, w-PAD, h-PAD));
        // Draw labels.
        Font font = g2.getFont();
        FontRenderContext frc = g2.getFontRenderContext();
        LineMetrics lm = font.getLineMetrics("0", frc);
        float sh = lm.getAscent() + lm.getDescent();
        
        // Ordinate label.
        float sy = PAD + ((h - 2*PAD) - y.length()*sh)/2 + lm.getAscent();
        for(int i = 0; i < y.length(); i++) {
            String letter = String.valueOf(y.charAt(i));
            float sw = (float)font.getStringBounds(letter, frc).getWidth();
            float sx = (PAD - sw)/2;
            g2.drawString(letter, sx, sy);
            sy += sh;
        }
        
        // Abcissa label.
        sy = h - PAD + (PAD - sh)/2 + lm.getAscent();
        float sw = (float)font.getStringBounds(x, frc).getWidth();
        float sx = (w - sw)/2;
        g2.drawString(x, sx, sy);

        // Draw lines.
        double xInc = (double)(w - 2*PAD)/(data.length-1);
        double scale = (double)(h - 2*PAD)/getMax();
        g2.setPaint(Color.green.darker());
        for(int i = 0; i < data.length-1; i++) {
        	if(i==data.length-2 && isFuzz==true)
        		break;
        	else{
            	double x1 = PAD + i*xInc;
            	double y1 = h - PAD - scale*data[i];
            	double x2 = PAD + (i+1)*xInc;
            	double y2 = h - PAD - scale*data[i+1];
            	g2.draw(new Line2D.Double(x1, y1, x2, y2));
            }
        }
        // Mark data points.
        for(int i = 0; i < data.length; i++) {
        	
        	if(i==data.length-1&&isFuzz==true)
        		break;
        	else{
            	double x = PAD + i*xInc;
            	double y = h - PAD - scale*data[i];
            	g2.setPaint(Color.red);
            	g2.fill(new Ellipse2D.Double(x-2, y-2, 8, 8));
            	g2.setPaint(Color.blue);
            	g2.drawString(("("+(i+1)+","+(int)data[i]+")"),(int)x,(int)y);
            }
        }	
    }
    private double getMax() {
        double max = -Double.MAX_VALUE;
        for(int i = 0; i < data.length; i++) {
            if(data[i] > max)
                max = data[i];
        }
        return max;
    }
}