import java.awt.Color ;
public class FuzzyNoiseReduction{
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
              HomeScreen hs =  new HomeScreen() ;
              hs.setBackground(Color.red) ;
              hs.setVisible(true);            
            }
        });
	}
}